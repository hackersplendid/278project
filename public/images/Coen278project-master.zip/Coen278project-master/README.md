# Coen278project
This is a Sinatra application for Student Management System. 
Assignmnet -3
COEN 278 - Advance Web Programming
Professor- Yaun Wang. 

Summary: The project involves a two database 
1) For adding student information including their details and managing the details
2) For adding comments information including their details and managing the details

There is only one username and password.

Username: anusha

Password: Coen278

The url to the heroku app is: https://anushacoen278sinatra.herokuapp.com/
